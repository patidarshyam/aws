import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Properties;

import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.awscore.exception.AwsServiceException;
import software.amazon.awssdk.core.exception.SdkClientException;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.Bucket;
import software.amazon.awssdk.services.s3.model.ListBucketsResponse;
import software.amazon.awssdk.services.s3.model.ObjectCannedACL;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectResponse;
import software.amazon.awssdk.services.s3.model.S3Exception;

public class AWSS3Main2 {

	private static String key;
	private static String secretKey;
	private static S3Client s3Client;
	public static String bucketName;
	public static final String ACCESS_KEY = "aws-s3-access-key";
	public static final String SECRET_KEY = "aws-s3-secret-key";
	public static final String BUCKET_NAME = "aws-s3-bucket-name";
	static {
		FileReader reader;
		try {
			reader = new FileReader("application.properties");
			Properties properties=new Properties();  
			properties.load(reader);  
		    key = properties.getProperty(ACCESS_KEY);
		    secretKey = properties.getProperty(SECRET_KEY);
		    bucketName= properties.getProperty(BUCKET_NAME);
		  //  System.out.println(key);  
		  //  System.out.println(secretKey); 
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}  
	}

	public static void main(String[] args) throws S3Exception, AwsServiceException, SdkClientException, FileNotFoundException, URISyntaxException {
		
		initialize();
		//uploadFile();
	}

	public static void initialize() {

		AwsBasicCredentials awsCreds = AwsBasicCredentials.create(key, secretKey);

		s3Client = S3Client.builder().credentialsProvider(StaticCredentialsProvider.create(awsCreds))
				.region(Region.AP_SOUTH_1).build();
		ListBucketsResponse l= s3Client.listBuckets();
		for (Bucket bucket : l.buckets()) {
			System.out.println("bucket name-"+bucket.name());
			if(bucket.name().equalsIgnoreCase(bucketName)) {
				try {
					uploadFile();
				} catch (S3Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (AwsServiceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SdkClientException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (URISyntaxException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}
	// public void uploadFile(DataObject dataObject)
	 public static void uploadFile() throws S3Exception, 
	    AwsServiceException, SdkClientException, URISyntaxException, 
	    FileNotFoundException {

		String fileName="test.html";
		String filePath="C:\\Users\\spatidar\\Desktop\\"+fileName;
	    PutObjectRequest putObjectRequest = PutObjectRequest.builder()
	        .bucket(bucketName).key(fileName) //key(dataObject.getName())
	        .acl(ObjectCannedACL.PUBLIC_READ_WRITE).build();
	    
			/*
			 AUTHENTICATED_READ,
			AWS_EXEC_READ,
			BUCKET_OWNER_FULL_CONTROL,
			BUCKET_OWNER_READ,
			PRIVATE,
			PUBLIC_READ,
			PUBLIC_READ_WRITE, and
			UNKNOWN_TO_SDK_VERSION.*/

//	    File file = new File(getClass().getClassLoader()
//	        .getResource(dataObject.getName()).getFile());
	    File file = new File(filePath);
	    
	    PutObjectResponse response = s3Client.putObject(putObjectRequest, RequestBody.fromFile(file));
	    System.out.println("file uploaded..."+response.toString());
	  
	  }
}
