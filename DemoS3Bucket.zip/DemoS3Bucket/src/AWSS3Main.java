import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.awscore.exception.AwsServiceException;
import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.core.exception.SdkClientException;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.CreateBucketRequest;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.DeleteObjectResponse;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.ListBucketsRequest;
import software.amazon.awssdk.services.s3.model.ListBucketsResponse;
import software.amazon.awssdk.services.s3.model.ListObjectsRequest;
import software.amazon.awssdk.services.s3.model.ListObjectsResponse;
import software.amazon.awssdk.services.s3.model.ObjectCannedACL;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectResponse;
import software.amazon.awssdk.services.s3.model.S3Exception;

public class AWSS3Main {

	private static String key;
	private static String secretKey;
	private static S3Client s3Client;
	public static String bucketName;
	public static final String ACCESS_KEY = "aws-s3-access-key";
	public static final String SECRET_KEY = "aws-s3-secret-key";
	public static final String BUCKET_NAME = "aws-s3-bucket-name";
	static {
		FileReader reader;
		try {
			reader = new FileReader("application.properties");
			Properties properties=new Properties();  
			properties.load(reader);  
		    key = properties.getProperty(ACCESS_KEY);
		    secretKey = properties.getProperty(SECRET_KEY);
		    bucketName= properties.getProperty(BUCKET_NAME);
		    System.out.println(key);  
		    System.out.println(secretKey); 
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}  
	}

	public static void main(String[] args) throws S3Exception, AwsServiceException, SdkClientException, URISyntaxException, IOException {
		
		//System.out.println(System.getProperty("user.dir"));
		initialize();
	//	uploadFile();
		String fileName="js.html";
		DataObject dataObject = new DataObject();
		  dataObject.setName(fileName);
		//  System.out.println("downloading file -"+dataObject.getName());
	//	  downloadFile(dataObject);  
		  
		  listObjects();
		//  deleteFile(dataObject);
		//  listObjects();
		  DataObject dataObject2= new DataObject();
		  dataObject2.setName("irsbucket");
		//  addBucket(dataObject2);
		  listBuckets();
	}

	public static void initialize() {

		AwsBasicCredentials awsCreds = AwsBasicCredentials.create(key, secretKey);

		s3Client = S3Client.builder().credentialsProvider(StaticCredentialsProvider.create(awsCreds))
				.region(Region.US_EAST_1).build();
		
	}
	// public void uploadFile(DataObject dataObject)
	 public static void uploadFile() throws S3Exception, 
	    AwsServiceException, SdkClientException, URISyntaxException, 
	    FileNotFoundException {

		String fileName="js.html";
		String filePath="C:\\Users\\spatidar\\Desktop\\"+fileName;
	    PutObjectRequest putObjectRequest = PutObjectRequest.builder()
	        .bucket(bucketName).key(fileName) //key(dataObject.getName())
	        .acl(ObjectCannedACL.PUBLIC_READ_WRITE).build();
	    
			/*
			 AUTHENTICATED_READ,
			AWS_EXEC_READ,
			BUCKET_OWNER_FULL_CONTROL,
			BUCKET_OWNER_READ,
			PRIVATE,
			PUBLIC_READ,
			PUBLIC_READ_WRITE, and
			UNKNOWN_TO_SDK_VERSION.*/

//	    File file = new File(getClass().getClassLoader()
//	        .getResource(dataObject.getName()).getFile());
	    File file = new File(filePath);
	    
	    PutObjectResponse response = s3Client.putObject(putObjectRequest, RequestBody.fromFile(file));
	    System.out.println("file uploaded..."+response.toString());
	  
	  }
	 
	 public static void downloadFile(DataObject dataObject) throws S3Exception, AwsServiceException, SdkClientException, IOException {

		  GetObjectRequest getObjectRequest = GetObjectRequest.builder()
		      .bucket(bucketName).key(dataObject.getName()).build();

		ResponseInputStream<GetObjectResponse> resp=  s3Client.getObject(getObjectRequest);
		
		 // Resource resource = new ClassPathResource(".");
		 // s3Client.getObject(getObjectRequest,Paths.get(resource.getURL().getPath()+"/test.png"));
		System.out.println(getObjectRequest);
		
		GetObjectResponse respObj= s3Client.getObject(getObjectRequest,Paths.get(System.getProperty("user.dir")+"\\downloads\\"+getObjectRequest.key()));
		System.out.println("resp obj -"+respObj);	
		//System.out.println(respObj.eTag());
	 
	 }
	 
	 public static List<String> listObjects() {

		  List<String> names = new ArrayList<>();
		  
		  ListObjectsRequest listObjectsRequest = ListObjectsRequest.builder().bucket(bucketName).build();
		  
		  ListObjectsResponse listObjectsResponse = s3Client.listObjects(listObjectsRequest);
		  listObjectsResponse.contents().stream()
		      .forEach(x -> names.add(x.key()));
		  
		  System.out.println("list - "+names);
		  return names;
	}
	 
	 public static void deleteFile(DataObject dataObject) {
		  DeleteObjectRequest deleteObjectRequest = DeleteObjectRequest.builder()
		      .bucket(bucketName).key(dataObject.getName()).build();
		 DeleteObjectResponse deleteObjectResponse= s3Client.deleteObject(deleteObjectRequest);
		 System.out.println("del obj-"+deleteObjectResponse);
		 System.out.println("deleted file -"+deleteObjectResponse.deleteMarker());
	}
	 
	 public static List<String> listBuckets() {
		  List<String> names = new ArrayList<>();
		  ListBucketsRequest listBucketsRequest = ListBucketsRequest.builder().build();
		  ListBucketsResponse listBucketsResponse = s3Client.listBuckets(listBucketsRequest);
		  listBucketsResponse.buckets().stream()
		      .forEach(x -> names.add(x.name()));
		  System.out.println("bucket list- "+names);
		  return names;
	}
	 
	 public static DataObject addBucket(DataObject dataObject) {
		  dataObject.setName(dataObject.getName() + System.currentTimeMillis());

		  CreateBucketRequest createBucketRequest = CreateBucketRequest
			       .builder()
			       .bucket(dataObject.getName()).build();
		        
		  s3Client.createBucket(createBucketRequest);
		  System.out.println("bucket name -"+dataObject.getName());
		  return dataObject;		
		}
}
